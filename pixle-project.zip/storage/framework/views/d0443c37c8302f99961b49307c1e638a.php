<div id="pixel-overlay" aria-hidden="true"></div>
<?php /**PATH D:\laragon\www\pixle\resources\views/partials/pixel-overlay.blade.php ENDPATH**/ ?>